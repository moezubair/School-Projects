int execute(char* args[],int background,int *cstatus);
int cd(char* args[],int size);

